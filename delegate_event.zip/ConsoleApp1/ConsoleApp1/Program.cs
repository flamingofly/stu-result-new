﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    //Static Constructor
    //1: Static constructor cannot have arguments
    //2: Static constructor can be created in non static class also
    //3: 
    internal class Program
    {
        static void Main(string[] args)
        {
            DelegateEventStudy study = new DelegateEventStudy(2);

            int result = study.Mydel(2, 4);

            TestClass anil = new ChildTestClass();
            anil.Show();

            
            Console.ReadLine();
           

        }
    }

   //Polymorphism
  // - Overriding = between parent and child
      //  -Overloading = with same class

    class TestClass
    {       
        static TestClass()
        {
            MyNum = 12;
        }

       public virtual void Show()
        {
            //yNum = 70;
            Console.WriteLine("Parent called");

        }

        public static int MyNum;
    }

    class ChildTestClass: TestClass
    {
        public override void Show()
        {
            Console.WriteLine(" Child test called");

            
        }
    }

   


}
