﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    //<accessibility> Delegate <returnType> DelegateName([parameters])
    public delegate int ArthmeticDelegate(int i, int j);

    internal class DelegateEventStudy
    {
        
        private ArthmeticDelegate mydel;
        private ArthmeticDelegate del1;
        private ArthmeticDelegate del2;

        public ArthmeticDelegate Mydel { get => mydel; set => mydel = value; }

        public DelegateEventStudy(int operationNumber)
        {
            //if (operationNumber == 1)
            //    mydel = Add;
            //else
            //    mydel = Substract;

            del1 = Add;
            del2 = Substract;
            mydel=  del2 + del1;
        }

        private int Add( int a, int b)
        {

            return a + b;
        }

        private int Substract(int a, int b)
        {

            return a - b;
        }

        //in build delegates in Dot NET
        // Action, Func, Predicate
    }


}
