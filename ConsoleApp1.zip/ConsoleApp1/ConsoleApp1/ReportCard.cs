﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    public class ReportCard
    {
        Student student;

        public Student Student { get => student; }

        public ReportCard(Student stu)
        {
            this.student = stu;
        }

       public void PrintStudentDetails()
        {
            Console.WriteLine("**********************************************");
            Console.WriteLine("Report Card for: "+ student.Name);
            Console.WriteLine("Standard: " + student.StuStandard.Name);

            Console.WriteLine("**********************************************");
        }

       public void PrintMarksDetails()
        {
            Console.WriteLine("Marks Detail:");

            if (student.GetType() == typeof(SeniorStudent))
            {  

                    foreach (var item in ((SeniorStudent)student).StuStream.lstSubjects)
                {
                    Console.WriteLine(item.Name + ": " + item.Marks);

                }
            }
            else
            {
                foreach (var item in student.StuStandard.LstSubject)
                {
                    Console.WriteLine(item.Name + ": " + item.Marks);

                }
            }

           
            Console.WriteLine("**********************************************");
            Console.WriteLine("Total : " + student.TotalMarks);
            
        }
    }
}
