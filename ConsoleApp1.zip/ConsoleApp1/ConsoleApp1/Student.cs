﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    public class Student
    {
        int id;
        string name;
        int phoneNumber;        
        Standard stuStandard;
        //int totalMarks;

        public int Id { get => id; set => id = value; }
        public string Name { get => name; set => name = value; }
        public int PhoneNumber { get => phoneNumber; set => phoneNumber = value; }
        public Standard StuStandard { get => stuStandard; set => stuStandard = value; }
        public int TotalMarks { 
            get => CalculateTotalMarks();
           }

         int CalculateTotalMarks()
        {
            int totakMarks=0;
            foreach (var item in StuStandard.LstSubject)
            {
                totakMarks += item.Marks;
            }
            return totakMarks;
        }


    }


      
    class SeniorStudent:Student
    {
        IStuStream stuStream;        
       
        public SeniorStudent(IStuStream selectedStream)
        {
            this.StuStream = selectedStream;
        }

        internal IStuStream StuStream { get => stuStream; set => stuStream = value; }

        // Dependency injection --- loose coupling 
    }
}
