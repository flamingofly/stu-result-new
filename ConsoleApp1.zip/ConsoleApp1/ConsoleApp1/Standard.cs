﻿using System.Collections.Generic;

namespace ConsoleApp1
{
    internal class Standard
    {
        List<Subject> lstSubject;
        int Name;
    }
}