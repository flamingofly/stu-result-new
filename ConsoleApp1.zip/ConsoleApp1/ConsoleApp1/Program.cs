﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Engineering eng = new Engineering();

                eng.StreamNumber = 100;

                int a= eng.StreamNumber;


            }
            catch (Exception ex)
            {

               // throw;
            }

            #region CommentedCode
            //  List<string> list = new List<string>();
            //  list.Add("Ankit");
            //  list.Add("Aman");
            //  list.Add("Animesh");
            //  list.Add("Shivam");

            //  //foreach (var item in list)
            //  //{
            //  //    Console.WriteLine(item);
            //  //}

            //  Dictionary<int, string> dict = new Dictionary<int, string>();
            //  dict.Add(1,"Ankit");
            //  dict.Add(2,"Aman");
            //  dict.Add(3,"Animesh");
            //  dict.Add(4,"Shivam");
            ////  dict.Add(4, "Shivam");

            // // Console.WriteLine(dict[6]);

            //  for (int i = 0; i < 2; i++)
            //  {
            //     if (i == 5) continue;
            //      Console.WriteLine(i);
            //  }

            //  5 factorial 

            //      5 *4*3

            //  //foreach (var item in dict)
            //  //{
            //  //    Console.WriteLine(item);
            //  //}

            //  // ArrayList arrList=new ArrayList();
            //  // arrList.Add("Surya");

            //  Console.ReadLine();


            //  //List --> ArrayList
            //  //Dictionary --- HashTable

            //  Stack<string> stack = new Stack<string>(); // ---
            //  Queue<string> queue = new Queue<string>(); // -----
            //  Queue   que=new Queue();


            //  //Array[5] array = new Array[5]();

            //  int[] arrCol = new int[5] {200,40,90,100,5}; 
            #endregion

        }
    }
}
