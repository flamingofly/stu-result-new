﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //ParentClass obj = new ChildClass();

            //obj.Show();


            try
            {

                Engineering strem= new Engineering();

                var a = typeof(Engineering);

               var b= strem.GetType();

               

                foreach (var item in strem.LstSubjects)
                {
                    if (item.Name=="Maths")
                    {
                        item.Marks = 70;
                    }
                    if (item.Name == "Physics")
                    {
                        item.Marks = 70;
                    }
                    if (item.Name == "Chemistry")
                    {
                        item.Marks = 70;
                    }
                } 
               


                SeniorStudent student = new SeniorStudent(strem);
                student.Id = 1;
                student.PhoneNumber = 987;
                student.Name = "Animesh";

                Standard st = new Standard();
                st.Name = 1;
                st.LstSubject = new List<Subject>();
                st.LstSubject.Add(new Subject() { Name = "Maths", Marks = 90 });
                st.LstSubject.Add(new Subject() { Name = "English", Marks = 60 });
                st.LstSubject.Add(new Subject() { Name = "Hindi", Marks = 80 });
                st.LstSubject.Add(new Subject() { Name = "EVS", Marks = 70 });

                student.StuStandard = st;

                ReportCard rp = new ReportCard(student);
                rp.PrintStudentDetails();
                rp.PrintMarksDetails();



                Console.ReadLine();


            }
            catch (Exception ex)
            {

               // throw;
            }

            #region CommentedCode
            //List<string> list = new List<string>();
            //list.Add("Ankit");
            //list.Add("Aman");
            //list.Add("Animesh");
            //list.Add("Shivam");

            ////foreach (var item in list)
            ////{
            ////    Console.WriteLine(item);
            ////}

            //Dictionary<int, string> dict = new Dictionary<int, string>();
            //dict.Add(1, "Ankit");
            //dict.Add(2, "Aman");
            //dict.Add(3, "Animesh");
            //dict.Add(4, "Shivam");
            ////  dict.Add(4, "Shivam");

            //// Console.WriteLine(dict[6]);

            //for (int i = 0; i < 2; i++)
            //{
            //    if (i == 5) continue;
            //    Console.WriteLine(i);
            //}

          

            //  //foreach (var item in dict)
            //  //{
            //  //    Console.WriteLine(item);
            //  //}

            //// ArrayList arrList=new ArrayList();
            //// arrList.Add("Surya");

            //  Console.ReadLine();


            ////List --> ArrayList
            ////Dictionary --- HashTable

            //Stack<string> stack = new Stack<string>(); // ---
            //Queue<string> queue = new Queue<string>(); // -----
            //Queue que = new Queue();


            ////Array[5] array = new Array[5]();

            //int[] arrCol = new int[5] { 200, 40, 90, 100, 5 };
            #endregion

        }
    }

    class Sample
    {
        public void Add (int a, int b)
        {
            Console.WriteLine(a + b);
        }

      public  void Add(string x)
        {
            Console.WriteLine("Print "+ x);

        }
    }
}
