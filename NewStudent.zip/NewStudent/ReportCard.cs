﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NewStudent
{
    class ReportCard
    {
        public void ShowDetails(Student student)
        {
            
            int totalmarks = 0, passmarks = 0, obtainmarks = 0, percentage = 0;
            
            Console.WriteLine("********************************************************************************");
            Console.WriteLine("Report Card for      : " + student.StudentName);
            Console.WriteLine("Student Id           : " + student.ID);
            Console.WriteLine("Class of Student     : " + student.Standard.Name);
            Console.WriteLine("********************************************************************************");
            

            Console.Write("Subjects \t :");
            foreach (var items in student.Standard.Subjects)
            {
                Console.Write(items.Name + "   ");
            }
            Console.WriteLine("Total");
            Console.WriteLine("\n");
            Console.Write("Total Marks \t :");
            foreach (var items in student.Standard.Subjects)
            {
                Console.Write(items.TotalMarks + " \t ");
                totalmarks += items.TotalMarks;
            }
            Console.WriteLine("\t" + totalmarks);
            Console.WriteLine("\n");
            Console.Write("Pass Marks \t :");
            foreach (var items in student.Standard.Subjects)
            {
                Console.Write(items.PassMarks + " \t ");
                passmarks += items.PassMarks;
            }
            Console.WriteLine("\t" + passmarks);
            Console.WriteLine("\n");
            Console.Write("Obtain Marks \t :");
            foreach (var items in student.Standard.Subjects)
            {
                Console.Write(items.ObtainMarks + " \t ");
                obtainmarks += items.ObtainMarks;
            }
            Console.WriteLine("\t" + obtainmarks);
            Console.WriteLine("\n");

            percentage = ((obtainmarks * 100) / totalmarks);
            Console.WriteLine("********************************************************************************");
            Console.WriteLine("Percentage       : " + percentage);
            Console.Write("Grade            : ");

            if (percentage > 90)
            {
                Console.WriteLine(GradeEnum.A);
            }
            else if (percentage > 80)
            {
                Console.WriteLine(GradeEnum.B);
            }
            else if (percentage > 70)
            {
                Console.WriteLine(GradeEnum.C);
            }
            else if (percentage > 60)
            {
                Console.WriteLine(GradeEnum.D);
            }
            else if (percentage > 50)
            {
                Console.WriteLine(GradeEnum.E);
            }
            else
            {
                Console.WriteLine(GradeEnum.F);
            }

            Console.WriteLine("********************************************************************************");
            
        }
    }
}
