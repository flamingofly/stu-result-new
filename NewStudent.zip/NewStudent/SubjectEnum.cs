﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NewStudent
{
    enum SubjectEnum
    {
        Hindi      ,
        English    ,
        Math       ,
        CS         ,
        EVS        ,
        Science    ,
        AdvanceMath,
        TotalTotalMarks,
        TotalPassMarks,
        TotalObtainMarks

    }
}
