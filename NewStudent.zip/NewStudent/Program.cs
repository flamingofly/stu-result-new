﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NewStudent
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.SetWindowSize(80, 58);
            Student stu1 = new Student();
            stu1.Standard = new Standard();
            stu1.Standard.Subjects = new List<Subject>();

            Console.Write("Enter Student Name                 (String Value): ");
            stu1.StudentName = Console.ReadLine();
            Console.Write("Enter Student ID                  (Integer Value): ");
            stu1.ID = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter Student Class (Interger Value from 7 to 11): ");
            stu1.Standard.Name = Console.ReadLine();

            var standard = Convert.ToInt32(stu1.Standard.Name);

            stu1.Standard.InitializeSubjets((StandardEnum)standard);


            Console.WriteLine("\nSubject Details\n");
            Console.WriteLine("Enter Obtained Marks Detail For Each Subject");

            foreach (var subject in stu1.Standard.Subjects)
            {
                Console.Write("{0}  :   ", subject.Name);
                subject.ObtainMarks = Convert.ToInt32(Console.ReadLine());

            }

            Console.Clear();
            ReportCard reportCard = new ReportCard();
            reportCard.ShowDetails(stu1);
            Console.ReadKey();
        }




        

    }
}
