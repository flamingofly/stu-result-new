﻿using System.Collections.Generic;

namespace NewStudent
{
    public class Standard
    {
        public string Name { get; set; }
        public List<Subject> Subjects { get; set; }


        public void InitializeSubjets(StandardEnum standard)
        {
            switch (standard)
            {
                case StandardEnum.Seventh:
                    AddSubject(SubjectEnum.Hindi.ToString());
                    AddSubject(SubjectEnum.English.ToString());
                    AddSubject(SubjectEnum.Math.ToString());
                                        
                    break;

                case StandardEnum.Eighth:
                    AddSubject(SubjectEnum.Hindi.ToString());
                    AddSubject(SubjectEnum.English.ToString());
                    AddSubject(SubjectEnum.Math.ToString());
                    AddSubject(SubjectEnum.EVS.ToString());

                    break;

                case StandardEnum.Nineth:
                    AddSubject(SubjectEnum.Hindi.ToString());
                    AddSubject(SubjectEnum.English.ToString());
                    AddSubject(SubjectEnum.Math.ToString());
                    AddSubject(SubjectEnum.EVS.ToString());
                    AddSubject(SubjectEnum.CS.ToString());

                    break;

                case StandardEnum.Tenth:
                    AddSubject(SubjectEnum.Hindi.ToString());
                    AddSubject(SubjectEnum.English.ToString());
                    AddSubject(SubjectEnum.Math.ToString());
                    AddSubject(SubjectEnum.EVS.ToString());
                    AddSubject(SubjectEnum.Science.ToString());

                    break;

                case StandardEnum.Eleventh:
                    AddSubject(SubjectEnum.Hindi.ToString());
                    AddSubject(SubjectEnum.English.ToString());
                    AddSubject(SubjectEnum.Math.ToString());
                    AddSubject(SubjectEnum.EVS.ToString());
                    AddSubject(SubjectEnum.Science.ToString());
                    AddSubject(SubjectEnum.AdvanceMath.ToString());

                    break;

                default:
                    break;
            }
        }


        private void AddSubject(string subjectName)
        {
            Subject subject = new Subject(subjectName);
            Subjects.Add(subject);

        }
    }
}
