﻿namespace NewStudent
{
    internal class Student
    {
        public int ID { get; set; }
        public string StudentName { get; set; }
        public Standard Standard { get; set; }

    }
}