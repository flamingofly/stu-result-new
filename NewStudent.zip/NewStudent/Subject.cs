﻿using System.Collections.Generic;

namespace NewStudent
{
    public class Subject
    {
        public Subject( string name)
        {
            Name = name;
            TotalMarks = 100;
            PassMarks = 30;
        }

        public string Name { get; set; }
        public int TotalMarks { get; set; }
        public int PassMarks { get; set; }
        public int ObtainMarks { get; set; }
    }
}
