﻿using System.Collections.Generic;

namespace ConsoleApp1
{
    public class Standard
    {
        List<Subject> lstSubject;
        int name;

        public int Name { get => name; set => name = value; }
        internal List<Subject> LstSubject { get => lstSubject; set => lstSubject = value; }
    }
}