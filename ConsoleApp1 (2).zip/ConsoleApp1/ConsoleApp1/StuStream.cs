﻿using System.Collections.Generic;

namespace ConsoleApp1
{
    internal interface IStuStream
    {

        int StreamNumber
        {
            get;
            set; 
        }

        List<Subject> LstSubjects
        {
            get;
            set;
        }

        void AddSubjects(Subject subject);
     
        //Engineering 
        //  Medicine 
        //  Commerce
        //  Arts 
    }

    class Engineering : IStuStream
    {
        int _streamNumber;

        public int StreamNumber { 
            get => GetNumber();
            set=> _streamNumber=value; 
        }
        public List<Subject> LstSubjects {
            get;
            set;
        }
        

        public Engineering()
        {
            LstSubjects = new List<Subject>();

            Subject physics=new Subject();
            physics.Name = "Physics";

            Subject maths = new Subject();
            maths.Name = "Maths";

            Subject chemistry = new Subject();
            chemistry.Name = "Chemistry";

            LstSubjects.Add(physics);
            LstSubjects.Add(maths);
            LstSubjects.Add(chemistry);


        }

        public void AddSubjects(Subject subject)
        {
         LstSubjects.Add(subject);
        }
    

        int GetNumber()
        {
            return _streamNumber;
        }
    }

    class MedicineStream : IStuStream
    {
        public int StreamNumber { get => throw new System.NotImplementedException(); set => throw new System.NotImplementedException(); }
        public List<Subject> LstSubjects { get => throw new System.NotImplementedException(); set => throw new System.NotImplementedException(); }

        public void AddSubjects(Subject subject)
        {
            throw new System.NotImplementedException();
        }


        public MedicineStream()
        {
            LstSubjects = new List<Subject>();

            Subject biology = new Subject();
            biology.Name = "Biology";

            Subject zoology = new Subject();
            zoology.Name = "Zoology";

            Subject chemistry = new Subject();
            chemistry.Name = "Chemistry";


        }
    }

}