﻿namespace ConsoleApp1
{
    internal class Subject
    {
         string name;
         int marks;

        public string Name { get => name; set => name = value; }
        public int Marks { get => marks; set => marks = value; }
    }
}