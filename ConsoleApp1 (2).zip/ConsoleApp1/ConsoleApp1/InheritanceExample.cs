﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
   public class ParentClass
    {

        protected virtual void Show()
        {
             
            Console.WriteLine("Parent Class Show called");
        }


    }

    public class ChildClass : ParentClass
    {
        protected override void Show()
        {
            Console.WriteLine("Child Class Show called");
        }

    }
}
