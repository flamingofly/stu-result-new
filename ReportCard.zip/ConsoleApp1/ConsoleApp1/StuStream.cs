﻿using System.Collections.Generic;

namespace ConsoleApp1
{
    internal interface IStuStream
    {

        int StreamNumber
        {
            get;
            set; 
        }

        List<Subject> lstSubjects
        {
            get;
            set;
        }

        void AddSubjects(Subject subject);
     
        //Engineering 
        //  Medicine 
        //  Commerce
        //  Arts 
    }

    class Engineering : IStuStream
    {
        int _streamNumber;

        public int StreamNumber { 
            get => GetNumber();
            set=> _streamNumber=value; 
        }
        public List<Subject> lstSubjects {
            get;
            set;
        }



        public Engineering()
        {
            lstSubjects = new List<Subject>();

            Subject physics=new Subject();
            physics.Name = "Physics";

            Subject maths = new Subject();
            physics.Name = "maths";

            Subject chemistry = new Subject();
            physics.Name = "chemistry";


        }

        public void AddSubjects(Subject subject)
        {
            throw new System.NotImplementedException();
        }

        int GetNumber()
        {
            return _streamNumber;
        }
    }

    class MedicineStream : IStuStream
    {
        public int StreamNumber { get => throw new System.NotImplementedException(); set => throw new System.NotImplementedException(); }
        public List<Subject> lstSubjects { get => throw new System.NotImplementedException(); set => throw new System.NotImplementedException(); }

        public void AddSubjects(Subject subject)
        {
            throw new System.NotImplementedException();
        }


        public MedicineStream()
        {
            lstSubjects = new List<Subject>();

            Subject biology = new Subject();
            biology.Name = "Biology";

            Subject zoology = new Subject();
            zoology.Name = "Zoology";

            Subject chemistry = new Subject();
            chemistry.Name = "Chemistry";


        }
    }

}