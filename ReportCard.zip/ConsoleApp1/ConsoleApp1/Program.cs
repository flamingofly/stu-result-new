﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            try
            {
              Student student = new Student();
                student.Id=1;
                student.PhoneNumber = 987;
                student.Name = "Animesh";

                Standard st = new Standard();
                st.Name = 1;
                st.LstSubject = new List<Subject>();
                st.LstSubject.Add(new Subject() { Name="Maths"});
                st.LstSubject.Add(new Subject() { Name = "English" });
                st.LstSubject.Add(new Subject() { Name = "Hindi" });
                st.LstSubject.Add(new Subject() { Name = "EVS" });

                student.StuStandard = st;

                ReportCard rp = new ReportCard(student);
                rp.PrintStudentDetails();
                rp.PrintMarksDetails();

                Console.ReadLine();


            }
            catch (Exception ex)
            {

               // throw;
            }

            #region CommentedCode
            //  List<string> list = new List<string>();
            //  list.Add("Ankit");
            //  list.Add("Aman");
            //  list.Add("Animesh");
            //  list.Add("Shivam");

            //  //foreach (var item in list)
            //  //{
            //  //    Console.WriteLine(item);
            //  //}

            //  Dictionary<int, string> dict = new Dictionary<int, string>();
            //  dict.Add(1,"Ankit");
            //  dict.Add(2,"Aman");
            //  dict.Add(3,"Animesh");
            //  dict.Add(4,"Shivam");
            ////  dict.Add(4, "Shivam");

            // // Console.WriteLine(dict[6]);

            //  for (int i = 0; i < 2; i++)
            //  {
            //     if (i == 5) continue;
            //      Console.WriteLine(i);
            //  }

            //  5 factorial 

            //      5 *4*3

            //  //foreach (var item in dict)
            //  //{
            //  //    Console.WriteLine(item);
            //  //}

            //  // ArrayList arrList=new ArrayList();
            //  // arrList.Add("Surya");

            //  Console.ReadLine();


            //  //List --> ArrayList
            //  //Dictionary --- HashTable

            //  Stack<string> stack = new Stack<string>(); // ---
            //  Queue<string> queue = new Queue<string>(); // -----
            //  Queue   que=new Queue();


            //  //Array[5] array = new Array[5]();

            //  int[] arrCol = new int[5] {200,40,90,100,5}; 
            #endregion

        }
    }
}
