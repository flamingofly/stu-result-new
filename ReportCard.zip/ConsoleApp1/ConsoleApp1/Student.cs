﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    public class Student
    {
        int id;
        string name;
        int phoneNumber;        
        Standard stuStandard;

        public int Id { get => id; set => id = value; }
        public string Name { get => name; set => name = value; }
        public int PhoneNumber { get => phoneNumber; set => phoneNumber = value; }
        public Standard StuStandard { get => stuStandard; set => stuStandard = value; }


    }

    class SeniorStudent:Student
    {
        IStuStream stuStream;
    }
}
