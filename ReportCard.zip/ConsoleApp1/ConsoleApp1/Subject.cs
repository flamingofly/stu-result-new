﻿namespace ConsoleApp1
{
    internal class Subject
    {
        private string name;

        public string Name { get => name; set => name = value; }
    }
}